StaffSync Demo — Modern Human Resource Management Solution

WHAT'S INCLUDED
- index.html: responsive HR dashboard prototype
- Dashboard, Employees, Attendance, Leave Requests, Payroll, Reports
- Add employee, employee search, leave approval/decline, print report
- Uses sample data; employee additions are saved in this browser only

IMPORTANT
This is a front-end demonstration, not a production HR system. It has no login,
server, database, real payroll processing, or multi-user sync. Do not enter real
employee personal or salary data.

HOW TO TEST LOCALLY
1. Extract the ZIP.
2. Double-click index.html to open it in a browser.

HOW TO PUBLISH A DEMO LINK WITH NETLIFY DROP
1. Open https://app.netlify.com/drop in your browser.
2. Sign in or create a Netlify account if asked.
3. Extract this ZIP first.
4. Drag the extracted folder containing index.html into the drop area.
5. Wait for deployment, then copy the generated public URL (usually ending in
   netlify.app). Open it in an incognito/private window to test it.
6. Paste that URL into SkillWallet using the pencil icon next to View Demo.

If Netlify asks for a folder, upload the extracted folder itself, not the ZIP.
For a public student project, use a neutral demo name and don't publish private data.
